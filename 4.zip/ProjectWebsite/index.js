function home(){
    var elmnt = document.getElementById("home");
    elmnt.scrollIntoView();
}
function intro(){
    var elmnt = document.getElementById("intro");
    elmnt.scrollIntoView();
}
function agent(){
    var elmnt = document.getElementById("agent");
    elmnt.scrollIntoView();
}
function map(){
    var elmnt = document.getElementById("map");
    elmnt.scrollIntoView();
}